
import java.io.IOException;

public class DuplicatedKeyException extends Exception{

	public DuplicatedKeyException(String message) {
		super(message);
	}
}
