
public class BlockedTicTacToe(){
	
	int board_size;
	int inline;
	int max_levels; 
	
	public BlockedTicTacToe (int board_size, int inline, int max_levels){
		char[][] gameBoard;	
		
		
	}
	public TTTDictionary createDictionary() {
		TTTDictionary dict =new TTTDictionary(5000);
		return dict;
	}
	public void insertConfig(TTTDictionary configurations, int score, int level){
		
	}
	
}
