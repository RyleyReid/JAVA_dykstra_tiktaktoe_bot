
public class InexistentKeyException extends Exception{
	
	public InexistentKeyException(String msg){
		super(msg);
	}

}
